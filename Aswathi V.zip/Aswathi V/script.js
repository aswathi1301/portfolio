// Dark Mode Toggle
const toggle = document.getElementById("darkModeToggle");
const body = document.body;

toggle.addEventListener("click", () => {
  body.classList.toggle("dark-mode");

  // Change toggle icon
  if (body.classList.contains("dark-mode")) {
    toggle.textContent = "☀️"; // Light mode icon
  } else {
    toggle.textContent = "🌙"; // Dark mode icon
  }
});

// Scroll Fade-in Animation
const faders = document.querySelectorAll(".fade-in");

const appearOptions = {
  threshold: 0.3,
  rootMargin: "0px 0px -50px 0px",
};

const appearOnScroll = new IntersectionObserver(function (
  entries,
  appearOnScroll
) {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add("appear");
    appearOnScroll.unobserve(entry.target);
  });
}, appearOptions);

faders.forEach((fader) => {
  appearOnScroll.observe(fader);
});
